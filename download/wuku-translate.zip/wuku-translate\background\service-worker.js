/**
 * WUKU Translate - Service Worker
 * 职责：右键菜单 / 快捷键 / 网络请求 / 缓存 / 配置初始化
 * 页面脚本不直接跨域请求，统一通过 runtime message 委托到这里执行。
 */
'use strict';

importScripts(
  '../shared/core.js',
  '../shared/constants.js',
  '../shared/lang-detect.js',
  '../shared/settings.js',
  '../shared/cache.js',
  '../shared/net.js',
  '../shared/engines/index.js',
  '../shared/engines/google.js',
  '../shared/engines/mymemory.js',
  '../shared/engines/ai.js',
  '../shared/engines/custom.js'
);

const MENUS = [
  { id: 'wuku-page', title: '翻译当前页面（译文）', contexts: ['page'] },
  { id: 'wuku-page-bilingual', title: '双语对照显示当前页面', contexts: ['page'] },
  { id: 'wuku-selection', title: '翻译选中文本', contexts: ['selection'] },
  { id: 'wuku-restore', title: '恢复原文', contexts: ['page', 'selection'] }
];

function setupMenus() {
  chrome.contextMenus.removeAll(() => {
    for (const menu of MENUS) {
      chrome.contextMenus.create(menu, () => {
        // 重复创建或菜单已存在时忽略
        void chrome.runtime.lastError;
      });
    }
  });
}

async function ensureDefaults() {
  const current = await WUKU.settings.get();
  await WUKU.settings.set(current);
}

chrome.runtime.onInstalled.addListener((details) => {
  setupMenus();
  ensureDefaults().catch(() => {});
  if (details.reason === 'install') {
    chrome.runtime.openOptionsPage().catch(() => {});
  }
});

chrome.runtime.onStartup.addListener(() => {
  setupMenus();
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (!tab || !tab.id) return;
  const payload = { type: 'noop' };
  if (info.menuItemId === 'wuku-page') payload.type = 'translate-page';
  else if (info.menuItemId === 'wuku-page-bilingual') payload.type = 'translate-page';
  else if (info.menuItemId === 'wuku-selection') payload.type = 'translate-selection';
  else if (info.menuItemId === 'wuku-restore') payload.type = 'restore';
  else return;

  if (info.menuItemId === 'wuku-page-bilingual') payload.mode = 'bilingual';
  if (info.menuItemId === 'wuku-page') payload.mode = 'immersive';
  if (info.menuItemId === 'wuku-selection' && info.selectionText) {
    payload.text = info.selectionText;
  }

  sendToTab(tab.id, payload).catch(() => {});
});

chrome.commands.onCommand.addListener((command, tab) => {
  const target = tab && tab.id ? tab.id : null;
  if (command === 'toggle-translate') {
    if (target) sendToTab(target, { type: 'toggle-translate' }).catch(() => {});
  } else if (command === 'translate-selection') {
    if (target) sendToTab(target, { type: 'translate-selection' }).catch(() => {});
  }
});

/**
 * 向标签页发送消息；页面在扩展安装前已加载时，先注入内容脚本再重试。
 */
async function sendToTab(tabId, message) {
  try {
    return await chrome.tabs.sendMessage(tabId, message);
  } catch (e) {
    try {
      await chrome.scripting.executeScript({
        target: { tabId },
        files: WUKU.constants.CONTENT_FILES
      });
      await chrome.scripting.insertCSS({
        target: { tabId },
        files: ['styles/content.css']
      });
      return await chrome.tabs.sendMessage(tabId, message);
    } catch (err) {
      throw WUKU.net.makeError('TAB_UNREACHABLE', '当前页面无法注入翻译脚本（chrome:// 页面或受限页面）');
    }
  }
}

function serializeError(error) {
  return {
    code: (error && error.code) || 'UNKNOWN',
    message: (error && error.message) || String(error),
    origin: (error && error.origin) || '',
    detail: (error && error.detail) || ''
  };
}

const handlers = {
  async ping() {
    return { pong: true, version: WUKU.version };
  },

  async translate(message) {
    const settings = await WUKU.settings.get();
    const outcome = await WUKU.engines.translateBatch({
      texts: message.texts || [],
      engineId: message.engineId,
      source: message.source || 'auto',
      target: message.target || settings.targetLang,
      settings,
      bypassCache: !!message.bypassCache
    });
    return outcome;
  },

  async 'test-engine'(message) {
    const settings = await WUKU.settings.get();
    const startedAt = Date.now();
    const outcome = await WUKU.engines.translateText(message.text || 'Hello, world.', {
      engineId: message.engineId,
      source: message.source || 'auto',
      target: message.target || settings.targetLang,
      settings,
      bypassCache: true
    });
    return {
      text: outcome.text,
      engineUsed: outcome.engineUsed,
      degraded: outcome.degraded,
      degradedReason: outcome.degradedReason,
      elapsed: Date.now() - startedAt
    };
  },

  async 'cache-stats'() {
    return WUKU.cache.stats();
  },

  async 'cache-clear'() {
    await WUKU.cache.clear();
    return { ok: true };
  },

  async 'open-options'() {
    await chrome.runtime.openOptionsPage();
    return { ok: true };
  },

  async 'permissions-check'(message) {
    const url = message.url || '';
    return { granted: await WUKU.net.hasHostPermission(url), origin: WUKU.net.originPatternFor(url) };
  }
};

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || typeof message.type !== 'string') return false;
  const handler = handlers[message.type];
  if (!handler) return false;

  Promise.resolve()
    .then(() => handler(message, sender))
    .then((data) => sendResponse({ ok: true, data }))
    .catch((error) => sendResponse({ ok: false, error: serializeError(error) }));

  return true;
});
